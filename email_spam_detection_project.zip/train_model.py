import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import pickle

# Sample data
data = {
    'text': [
        'Congratulations! You have won a lottery. Claim now.',
        'Reminder: Your meeting is scheduled at 10 AM tomorrow.',
        'Free entry in a contest. Click here to win an iPhone.',
        'Hi, are we still meeting for lunch today?',
        'You have been selected for a cash prize. Reply WIN to claim.',
        'Please review the attached document and send feedback.',
        'URGENT! You are selected for a $1000 gift card.'
    ],
    'label': [1, 0, 1, 0, 1, 0, 1]
}

df = pd.DataFrame(data)

vectorizer = CountVectorizer()
X = vectorizer.fit_transform(df['text'])
y = df['label']

model = MultinomialNB()
model.fit(X, y)

with open('spam_model.pkl', 'wb') as f:
    pickle.dump(model, f)

with open('vectorizer.pkl', 'wb') as f:
    pickle.dump(vectorizer, f)

print("✅ Model and vectorizer saved successfully.")
